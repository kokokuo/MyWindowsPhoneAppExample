﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using DataContractJsonSerializer_WP8.Resources;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;
using System.IO.IsolatedStorage;
using System.Diagnostics;
using System.IO;
namespace DataContractJsonSerializer_WP8
{
    public partial class MainPage : PhoneApplicationPage
    {
        string fileName;
        IsolatedStorageFile recordFile;
        string recordTargetFolderName;
        DataContractJsonSerializer JsonSerializer;
        // 建構函式
        public MainPage()
        {
            InitializeComponent();
            recordFile = IsolatedStorageFile.GetUserStoreForApplication();
            fileName = "student.txt";
            recordTargetFolderName = "StudentRecord";
            JsonSerializer = new DataContractJsonSerializer(typeof(Student));
        }


        /// <summary>
        /// 載入檔案
        /// </summary>
        /// <returns></returns>
        public Student LoadData()
        {
            Student s = null;
            string TargetFileName = String.Format("{0}\\{1}",
                                              recordTargetFolderName, fileName);
            try
            {
                if (recordFile.FileExists(TargetFileName))
                {
                    using (var sourceStream = recordFile.OpenFile(TargetFileName, FileMode.Open))
                    {
                        s = (Student)JsonSerializer.ReadObject(sourceStream);
                    }
                }
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);

            }
            return s;
        }

        /// <summary>
        /// 以序列化方式存檔存入
        /// </summary>
        /// <param name="saveData"></param>
        public void SaveData(Student saveData)
        {
            string TargetFileName = String.Format("{0}\\{1}",
                                             recordTargetFolderName, fileName);

            if (!recordFile.DirectoryExists(recordTargetFolderName))
                recordFile.CreateDirectory(recordTargetFolderName);
            try
            {
                using (var targetFile = recordFile.CreateFile(TargetFileName))
                {
                    JsonSerializer.WriteObject(targetFile, saveData);
                }
               
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }

        private void saveButton_Click(object sender, RoutedEventArgs e)
        {
            int id;
            if (nameTxt.Text != "" && IdTxt.Text != null && int.TryParse(IdTxt.Text, out id))
            {
                Student s = new Student(id, nameTxt.Text, (bool)graduatedCheckbox.IsChecked);
                SaveData(s);
                MessageBox.Show("Saved.");
            }
            else {
                MessageBox.Show("Data Not Correct...");
            }
        }

        private void loadButton_Click(object sender, RoutedEventArgs e)
        {
            Student s = LoadData();
            if (s != null) { 
                MessageBox.Show("Name = " + s.Name +"\nID = " +s.ID + "\nGraduated =" +  s.Graduated);
            }
        }
    }

    [DataContract]
    public class Student {

        public Student(int id, string name, bool isGraduated) {
            ID = id;
            Name = name;
            Graduated = isGraduated;
        }

        [DataMember(Name="StudentID")]
        public int ID { get; set; }
        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public bool Graduated;


    }
    
}