﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using HtmlAgilityPack;
using System.Diagnostics;
using System.Text;
namespace HelloHtmlAgilityPack_WP7
{
    public partial class MainPage : PhoneApplicationPage
    {
        // 建構函式
        public MainPage()
        {
            InitializeComponent();

            // 將 ApplicationBar 當地語系化的程式碼範例
            //BuildLocalizedApplicationBar();

            HtmlWeb client = new HtmlWeb();
            client.LoadCompleted += client_LoadCompleted;
            
            //中油網站 http://www.cpc.com.tw/big5/home/index.asp 
            
            client.LoadAsync("http://astro.click108.com.tw/daily_10.php?iAstro=10");
            /*
            for (int i = 0; i < 10; i++)
            {
                client.LoadAsync("http://astro.click108.com.tw/daily_" + i + ".php?iAstro=" + i);
            }*/
        }

        private void client_LoadCompleted(object sender, HtmlDocumentLoadCompleted e)
        {
            try
            {
                if (e.Error == null)
                {
                    HtmlDocument doc = e.Document;
                    if (doc != null)
                    {
                        Debug.WriteLine("connect ok");
                        //Get Name
                        Debug.WriteLine("Name:");
                        
                        HtmlNodeCollection nameNodes = doc.DocumentNode.SelectNodes(@"//div[@class='ROOT']/p/a[2]");
                        foreach (HtmlNode node in nameNodes)
                        {
                            string strValue = (node.InnerText);//.Substring(5);

                            Debug.WriteLine(strValue);
                        }


                        Debug.WriteLine("All:");
                        HtmlNodeCollection allFortuneContentNodes = doc.DocumentNode.SelectNodes(@"//div[@class='TODAY_CONTENT']/dt[@btype='all']/p");
                        foreach (HtmlNode node in allFortuneContentNodes)
                        {
                            string strValue = (node.InnerText);

                            Debug.WriteLine(strValue);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }
    }
}