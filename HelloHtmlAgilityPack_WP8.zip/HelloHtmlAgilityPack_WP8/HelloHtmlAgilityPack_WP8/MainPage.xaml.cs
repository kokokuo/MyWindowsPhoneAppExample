﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using HelloHtmlAgilityPack_WP8.Resources;
using HtmlAgilityPack;
using System.Diagnostics;
using System.Text;
namespace HelloHtmlAgilityPack_WP8
{
    public partial class MainPage : PhoneApplicationPage
    {
        // 建構函式
        public MainPage()
        {
            InitializeComponent();
            HtmlWeb client = new HtmlWeb();
            client.LoadCompleted += client_LoadCompleted;

            client.LoadAsync("http://astro.click108.com.tw/daily_10.php?iAstro=10");
           
        }

        private void client_LoadCompleted(object sender, HtmlDocumentLoadCompleted e)
        {
            try
            {
                if (e.Error == null)
                {
                    HtmlDocument doc = e.Document;
                    if (doc != null)
                    {
                        Debug.WriteLine("connect ok");
                        //Get Name
                        Debug.WriteLine("Name:");

                        HtmlNodeCollection nameNodes = doc.DocumentNode.SelectNodes(@"//div[@class='ROOT']/p/a[2]");
                        foreach (HtmlNode node in nameNodes)
                        {
                            string strValue = (node.InnerText);//.Substring(5);

                            Debug.WriteLine(strValue);
                        }


                        Debug.WriteLine("All:");
                        HtmlNodeCollection allFortuneContentNodes = doc.DocumentNode.SelectNodes(@"//div[@class='TODAY_CONTENT']/dt[@btype='all']/p");
                        foreach (HtmlNode node in allFortuneContentNodes)
                        {
                            string strValue = (node.InnerText);

                            Debug.WriteLine(strValue);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }
    }
}