﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using HelloStoryboardComplete.Resources;

namespace HelloStoryboardComplete
{
    public partial class MainPage : PhoneApplicationPage
    {
        // 建構函式
        public MainPage()
        {
            InitializeComponent();

            // 將 ApplicationBar 當地語系化的程式碼範例
            //BuildLocalizedApplicationBar();
            this.Loaded += new RoutedEventHandler(NavigationPage_Loaded);
        }
        void NavigationPage_Loaded(object sender, RoutedEventArgs e)
        {
            //如果你需要再進到Page時馬上處理動畫，可以透過Loaded事件
            //myStoryboard.Begin();
        }


        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            myStoryboard.Begin();
            //Not here
            //NavigationService.Navigate(new Uri("/Page2.xaml", UriKind.Relative));
        }
        //當動畫播完後會進入此事件，導向遊戲選單
        private void DoubleAnimation_Completed(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/Page2.xaml", UriKind.Relative));
        }

        private void myStoryboard_Completed(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/Page2.xaml", UriKind.Relative));
        }

     
    }
}