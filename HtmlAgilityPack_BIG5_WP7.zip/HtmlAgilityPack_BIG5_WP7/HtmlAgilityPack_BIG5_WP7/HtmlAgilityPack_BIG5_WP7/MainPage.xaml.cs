﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using HtmlAgilityPack;
using System.Diagnostics;
using System.Text;
namespace HtmlAgilityPack_BIG5_WP7
{
    public partial class MainPage : PhoneApplicationPage
    {
        WebBrowser htmlbrowser;
        // 建構函式
        public MainPage()
        {
            InitializeComponent();

            // 將 ApplicationBar 當地語系化的程式碼範例
            //BuildLocalizedApplicationBar();

            
            //中油網站 http://www.cpc.com.tw/big5/home/index.asp 
            htmlbrowser = new WebBrowser();
	        htmlbrowser.LoadCompleted += browser_LoadCompleted;
	        htmlbrowser.Source = new Uri("http://www.cpc.com.tw/big5/home/index.asp ");
        }

        private void browser_LoadCompleted(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {

            try
            {
                string contentHTML = htmlbrowser.SaveToString();
                HtmlDocument htmlDoc = new HtmlDocument();
                htmlDoc.LoadHtml(contentHTML);
                HtmlNodeCollection nameNodes = htmlDoc.DocumentNode.SelectNodes("/html/body/table/tbody/tr[2]/td/marquee");
                foreach (HtmlNode node in nameNodes)
                {
                    string strValue = (node.InnerText);

                    Debug.WriteLine(strValue);
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }
    }
}